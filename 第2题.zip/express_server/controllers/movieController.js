const movieService = require("../services/movieService");

// 获取所有电影
exports.getMovies = async (req, res, next) => {
  console.log("getMovies");
  try {
    const movies = await movieService.getMovies();
    res.json({
      code: 200,
      success: true,
      message: "查询电影信息成功",
      data: {
        films: movies,
      },
    });
  } catch (error) {
    next(error);
  }
};

// 根据 ID 获取单个电影
exports.getMovieById = async (req, res, next) => {
  try {
    const movie = await movieService.getMovieById(req.params.id);
    res.json({
      code: 200,
      success: true,
      message: "查询电影信息成功",
      data: movie,
    });
  } catch (error) {
    next(error);
  }
};

// 创建电影
exports.createMovie = async (req, res, next) => {
  const newMovie = req.body;
  console.log(newMovie,'newMovie')
  newMovie.imgUrl = "http://localhost:5000/images/peoples/员工.png";
  const createMovieResult = await movieService.getMovieByName(newMovie.name);
  const createMovieResult2 = await movieService.getMovieById(newMovie.filmId);  
  if (createMovieResult || createMovieResult2) {
    return res.send({
      code: 1004,
      success: false,
      message: "电影名称或电影编号已存在，请重新输入",
    });
  }
  try {
    const movie = await movieService.createMovie(newMovie);
    res.json({
      code: 200,
      success: true,
      message: "创建电影信息成功",
      data: movie,
    });
  } catch (error) {
    next(error);
  }
};

// 更新电影


exports.updateMovie = async (req, res, next) => {
  try {
    const updatedMovie = req.body;

    // 通过id查找是否存在这个用户
    const updateMovieResult = await movieService.getMovieById(updatedMovie.id);
    console.log(updateMovieResult,'updateMovieResult')  
    if (!updateMovieResult) {
      // updateMovieResult是null
      return res.send({
        code: 1005,
        success: false,
        message: "电影id不存在,请确认修改id！",
      });
    }else {
      updatedMovie.posterUrl = updateMovieResult.posterUrl;
      // 更新用户
      await movieService.updateMovie(updatedMovie);
      res.send({
        code: 200,
        success: true,
        message: "更新电影信息成功",
      });
    }
  } catch (err) {
    next(err);
  }
};

// 删除电影
exports.deleteMovie = async (req, res, next) => {
  try {
    await movieService.deleteMovie(req.params.id);
    res.json({
      code: 200,
      success: true,
      message: "删除电影信息成功",
    });
  } catch (error) {
    next(error);
  }
};

// 根据 ID 增加每个movie的评分
exports.addPopularityById = async (req, res, next) => {
  try {
    const movie = await movieService.addPopularityById(req.params.id);
      res.json({
      code: 200,
      success: true,
      message: "增加电影评分成功",
      data: movie,
    });
  } catch (error) {
    next(error);
  }
};

