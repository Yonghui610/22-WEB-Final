const userService = require("../services/userService");

// 引入
const jwt = require("jsonwebtoken");


// 登录
exports.login = async (req, res, next) => {
  try {
    const { name, pwd, QQ } = req.body;
    const user = await userService.getUserByName(name);
    if (!user) {
      return res.send({
        code: 1001,
        success: false,
        message: "账号不存在",
      });
    }
    if (user.pwd !== pwd) {
      return res.send({
        code: 1002,
        success: false,
        message: "密码错误",
      });
    }
    if (user.QQ !== QQ) {
      return res.send({
        code: 1002,
        success: false,
        message: "QQ号错误",
      });
    }

    // 登录成功，生成token
    const secretKey = "chaojianquanmima";
    const token = jwt.sign({ user }, secretKey, { expiresIn: "1h" });

    // 区分管理员或其他用户
    if (user.name === "20222830") {
      return res.send({
        code: 200,
        success: true,
        message: "登录成功",
        data: {
          token,
          data: user,
          nickname: "管理员",
        },
      });
    } else {
      return res.send({
        code: 200,
        success: true,
        message: "登录成功",
        data: {
          token,
          data: user,
          nickname: "普通用户",
        },
      });
    }
  } catch (err) {
    next(err);
  }
};

// 注册
exports.register = async (req, res, next) => {
  try {
    const { name, pwd, age, gender, address, QQ } = req.body;

    // 检查用户名是否已存在
    const existingUser = await userService.getUserByName(name);
    if (existingUser) {
      return res.send({
        code: 1004,
        success: false,
        message: "账号已存在，请重新输入",
      });
    }

    // 创建用户
    const userId = await userService.createUser({
      name,
      pwd,
      age,
      gender,
      address,
      QQ,
      imgUrl: "http://localhost:5000/images/peoples/员工.png", // 默认头像
    });

    // 根据返回的 userId 查询完整用户信息
    const newUser = await userService.getUserById(userId);

    // 如果查询不到用户信息，返回错误
    if (!newUser) {
      return res.send({
        code: 1005,
        success: false,
        message: "注册成功，但无法加载用户信息",
      });
    }

    // 登录成功，生成 Token
    const secretKey = "chaojianquanmima";
    const token = jwt.sign({ user: newUser }, secretKey, { expiresIn: "1h" });

    // 返回成功信息
    res.send({
      code: 200,
      success: true,
      message: "注册成功",
      data: {
        token,
        data: newUser, // 包含完整用户信息，包括 id
        nickname: "普通用户",
      },
    });
  } catch (err) {
    next(err);
  }
};

// 获取所有用户
exports.getUsers = async (req, res, next) => {
  try {
    const users = await userService.getUsers();
    if (!users) {
      // return res.status(403).send({  // 增加前端判断难度 axios中catch分支处理
      return res.send({
        //  axios中then分支处理
        code: 404,
        success: false,
        message: "未找到学生信息",
      });
    } else {
      const filteredUsers = users.filter((user) => user.name !== '20222830');
      res.send({
        code: 200,
        success: true,
        message: "查询学生信息成功",
        data: filteredUsers,
      });
    }
  } catch (err) {
    next(err);
  }
};

//通过QQ查询
exports.getUserByQQ = async (req, res, next) => {
  try {
    const users = await userService.getUserByQQ(req.params.qq);
    if (!users || users.length === 0) {
      return res.send({
        code: 1003,
        success: false,
        message: "未找到符合条件的用户！",
      });
    } else {
      res.send({
        code: 200,
        success: true,
        message: "查询用户成功！",
        data: users,
      });
    }
  } catch (err) {
    next(err);
  }
};

// 根据 ID 获取单个用户
exports.getUserById = async (req, res, next) => {
  try {
    const user = await userService.getUserById(req.params.id);
    if (!user) {
      return res.send({
        code: 1003,
        success: false,
        message: "获取用户数据失败,请确认查询id！",
      });
    } else {
      res.send({
        code: 200,
        success: true,
        message: "查询学生信息成功",
        data: user,
      });
    }
  } catch (err) {
    next(err);
  }
};


// 创建新用户
exports.createUser = async (req, res, next) => {
  try {
    const newUser = req.body;
    console.log(newUser);

    // 调用服务层创建用户
    const userId = await userService.createUser(newUser);

    // 返回成功响应
    res.send({
      code: 200,
      success: true,
      message: "添加学生信息成功",
      data: {
        data: userId,
        nickname: "普通注册用户",
      },
    });
  } catch (err) {
    next(err);
  }
};

// 删除用户
exports.deleteUser = async (req, res, next) => {
  try {
    const deleteUserId = req.params.id;
    const deleteUserResult = await userService.getUserById(deleteUserId);

    if (!deleteUserResult) {
      return res.send({
        code: 1006,
        success: false,
        message: "学生id不存在,请确认删除id！",
      });
    } else {
      await userService.deleteUser(deleteUserId);
      res.send({
        code: 200,
        success: true,
        message: "删除学生信息成功",
      });
    }
  } catch (err) {
    next(err);
  }
};

// 更新用户
exports.updateUser = async (req, res, next) => {
  try {
    const updatedUser = req.body;

    // 调用服务层更新用户
    await userService.updateUser(updatedUser);

    // 返回成功响应
    res.send({
      code: 200,
      success: true,
      message: "更新学生信息成功",
    });
  } catch (err) {
    next(err);
  }
};

//更新年龄
exports.updateUserAge = async (req, res, next) => {
  try {
    const { id, age } = req.body;
    await userService.updateUserAge(id, age);
    res.send({
      code: 200,
      success: true,
      message: "年龄更新成功",
    });
  } catch (err) {
    next(err);
  }
};

//修改密码
exports.updatePassword = async (req, res, next) => {
  try {
    const { id, newPassword } = req.body;
    await userService.updatePassword(id, newPassword);
    res.send({
      code: 200,
      success: true,
      message: "密码修改成功",
    });
  } catch (err) {
    next(err);
  }
};

//修改QQ
exports.updateQQ = async (req, res, next) => {
  try {
    const { id, newQQ } = req.body;
    await userService.updateQQ(id, newQQ);
    res.send({
      code: 200,
      success: true,
      message: "QQ修改成功",
    });
  } catch (err) {
    next(err);
  }
};