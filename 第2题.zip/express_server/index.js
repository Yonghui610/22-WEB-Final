const express = require("express");
const app = express();
const path = require("path");


// cors
const cors = require("cors")
app.use(cors());

// 设置静态文件夹
app.use(express.static(path.join(__dirname, "public")));

// 解析 JSON 和 URL 编码的请求体
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// 引入主路由
const mainRouter = require("./routes/index");
// 注册主路由
app.use("/", mainRouter);

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send({
    code: 500,
    message: "服务器发生错误",
  });
});

// 启动服务器
app.listen(5000, () => {
  console.log("服务器已经启动！   http://localhost:5000");
});
