const express = require("express");
const router = express.Router();

// 使用user路由
router.use("/stus", require("./users"));

// 使用movie路由
router.use("/movies", require("./movies")); 
// 使用其他...
module.exports = router;
