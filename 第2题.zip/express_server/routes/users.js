const express = require("express");
const router = express.Router();
const authenticationToken = require("../middleware/authenticationToken");
const userController = require("../controllers/userController");

// 登录   
router.post("/login", userController.login);

// 注册
router.post("/register", userController.register);

// 使用中间件保护其他路由  登录路由不需要验证 token
router.use(authenticationToken);

// 添加错误Token处理中间件
router.use(authenticationToken.handleJwtError);


// 获取所有用户
router.get("/users", userController.getUsers);

// 根据 ID 获取单个用户
router.get("/users/:id", userController.getUserById);

//根据QQ获得单个用户
router.get("/users/qq/:qq", userController.getUserByQQ);

// 创建新用户
router.post("/users", userController.createUser);


// 删除用户
router.delete("/users/:id", userController.deleteUser);

// 更新用户
router.put("/users", userController.updateUser);

router.put("/users/age", userController.updateUserAge);

router.put("/users/password", userController.updatePassword);

router.put("/users/QQ", userController.updateQQ);

module.exports = router;
