const express = require("express");
const router = express.Router();
const moviesController = require("../controllers/movieController");
const authenticationToken = require("../middleware/authenticationToken");


// 获取所有movies
router.get("/movies", moviesController.getMovies);

// 根据 ID 获取单个movie
router.get("/movies/:id", moviesController.getMovieById);

// 根据 ID 增加每个movie的评分
router.get("/moviespopularity/:id", moviesController.addPopularityById);


// 使用中间件保护其他路由  登录路由不需要验证 token
router.use(authenticationToken);

// 添加错误Token处理中间件
router.use(authenticationToken.handleJwtError);

// 更新movie
router.put("/movies", moviesController.updateMovie);

// 添加新movie
router.post("/movies", moviesController.createMovie);


// 删除movie
router.delete("/movies/:id", moviesController.deleteMovie);




module.exports = router;

