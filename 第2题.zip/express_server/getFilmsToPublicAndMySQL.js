
// F5   或终端下运行 node getFilmsToPublicAndMySQL.js

const axios = require("axios");
const path = require("node:path");
const fs = require("fs");
const fsPromises = require("node:fs/promises");
const mysql = require("mysql2/promise");

let films1 = [];
let films2 = [];

// 配置 MySQL 连接
const config = {
  host: "127.0.0.1",
  port: 3306,
  user: "root",
  password: "Wyh195964$&",
  database: "wyhdb2",
  connectionLimit: 5,
};

// 获取电影列表
async function getMoviesList() {
  try {
    let res = await axios(
      "https://m.maizuo.com/gateway?cityId=120100&pageNum=1&pageSize=50&type=1&k=7251228",
      {
        headers: {
          "X-Client-Info":
            '{"a":"3000","ch":"1002","v":"5.2.1","e":"17209289107592677545607169","bc":"120100"}',
          "X-Host": "mall.film-ticket.film.list",
        },
      }
    );

    films1 = res.data.data.films;
    // console.log(films1);
    // 文件保存请求回来的数据
    await fsPromises.writeFile(
      path.resolve(__dirname, "./filmsArray1.js"),
      `${JSON.stringify(films1)};`
    );
    // 挑选、整理数据，并保存
    films2 = films1.map((movie) => ({
      filmId: movie.filmId,
      name: movie.name,
      director: movie.director,
      category: movie.category,
      runtime: movie.runtime,
      posterUrl: movie.poster,
      description: movie.synopsis,
      popularity: parseFloat(movie.grade) * 10 + "",
    }));
    // console.log(films2);
    await fsPromises.writeFile(
      path.resolve(__dirname, "./filmsArray2.js"),
      `${JSON.stringify(films2)};`
    );
  } catch (err) {
    console.log("出错了！", err);
  }
}

// 下载并保存图片
const downloadImage = async (url, path) => {
  try {
    const response = await axios({
      method: "get",
      url: url,
      responseType: "stream",
    });

    return new Promise((resolve, reject) => {
      response.data
        .pipe(fs.createWriteStream(path))
        .on("finish", resolve)
        .on("error", reject);
    });
  } catch (error) {
    throw new Error(`下载图片时出错: ${error.message}`);
  }
};

// 确保目录存在 public/images/movies/
const ensureDirectoryExists = async (dirPath) => {
  try {
    await fsPromises.mkdir(dirPath, { recursive: true });
  } catch (error) {
    console.error(`创建目录时出错: ${error.message}`);
  }
};

// 更新海报路径并保存到数据库
const updatePostersAndSaveToDB = async () => {
  const imagesDir = path.join(__dirname, "public/images/movies");
  // 确保目录存在
  await ensureDirectoryExists(imagesDir);

  const connection = mysql.createPool(config);

  for (const movie of films2) {
    const { name, posterUrl } = movie;
    // 原始数据url
    const url = posterUrl;
    const imagePath = path.join(imagesDir, `${name}.jpg`);

    try {
      // 用原始数据url下载图片
      await downloadImage(url, imagePath);

      // 更新 poster 字段
      movie.posterUrl = `http://localhost:5000/images/movies/${name}.jpg`;
      console.log(`图片 ${name} 已成功保存到 ${imagePath}`);

      // 插入数据到数据库
      const [result] = await connection.execute(
        "INSERT INTO wyhtable2 (filmId, name, director,category,runtime,description, posterUrl, popularity) VALUES (?, ?, ?, ?, ?,?,?,?)",
        [
          movie.filmId,
          movie.name,
          movie.director,
          movie.category,
          movie.runtime,
          movie.description,
          movie.posterUrl,
          movie.popularity,
        ]
      );
      console.log(`电影 ${name} 已成功保存到数据库`);
    } catch (error) {
      console.error(`处理电影 ${name} 时出错:`, error);
    }
  }

  await connection.end();
  console.log("所有数据已成功保存到数据库");
};

(async () => {
  await getMoviesList();
  await updatePostersAndSaveToDB();
})();
