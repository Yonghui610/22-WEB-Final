const Movie = require("../models/Movie");

// 获取所有电影
exports.getMovies = async () => {
  try {
    const movies = await Movie.getMovies();
    return movies;
  } catch (err) {
    console.error("Error fetching movies:", err.message);
    throw err;
  }
};

// 根据 ID 获取单个电影
exports.getMovieById = async (id) => {
  const movie = await Movie.getMovieById(id);
  return movie;
};

// 根据电影名称获取电影
exports.getMovieByName = async (name) => {
  const movie = await Movie.getMovieByName(name);
  return movie;
};
// 根据 ID 增加每个movie的评分
exports.addPopularityById = async (id) => {
  const movie = await Movie.addPopularityById(id);
  return movie;
};

// 创建电影
exports.createMovie = async (movie) => {
  const newMovie = await Movie.createMovie(
    movie.filmId,
    movie.name,
    movie.description,
    movie.imgUrl,
    movie.popularity
  );
  return newMovie;
};

// 更新电影
exports.updateMovie = async (movie) => {
  console.log(movie,'movie123123')
  try {
    await Movie.updateMovie(
      movie.id,
      movie.filmId,
      movie.name,
      movie.description,
      movie.posterUrl,
      movie.popularity
    );
  } catch (err) {
    console.error(`Error updating movie with ID ${movie.id}:`, err.message);
    throw err;
  }
};

// 删除电影
exports.deleteMovie = async (id) => {
  const deletedMovie = await Movie.deleteMovie(id);
  return deletedMovie;
};

