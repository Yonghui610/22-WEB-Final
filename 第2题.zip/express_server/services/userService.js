const User = require("../models/User");

// 获取所有用户
exports.getUsers = async () => {
  try {
    const users = await User.getUsers();
    return users;
  } catch (err) {
    console.error("Error fetching users:", err.message);
    throw err;
  }
};

// 根据 name  获取单个用户
exports.getUserByName = async (userName) => {
  try {
    const user = await User.getUserByName(userName);
    if (!user) {
      // user是null  账号不存在
      return null;
    }
    return user;
    // resolve
  } catch (err) {
    // reject
    // await失败时，处理错误，抛出异常  由调用者 await userService.getUserByName() 捕获，继而再catch处理
    console.error(
      `Error fetching user with Name and Pwd ${userName}:`,
      err.message
    );
    throw err;
  }
};

exports.getUserByQQ = async (userQQ) => {
  try {
    const users = await User.getUserByQQ(userQQ);
    if (!users || users.length === 0) {
      return [];
    }
    return users;
  } catch (err) {
    console.error(`Error fetching users with QQ ${userQQ}:`, err.message);
    throw err;
  }
};


// 根据 ID 获取单个用户
exports.getUserById = async (userId) => {
  try {
    const user = await User.getUserById(userId);
    if (!user) {
      return null;
    }
    return user;
  } catch (err) {
    console.error(`Error fetching user with ID ${userId}:`, err.message);
    throw err;
  }
};

// 创建新用户
exports.createUser = async (userData) => {
  try {
    // 检查是否存在同名用户
    const existingUser = await User.getUserByName(userData.name);
    if (existingUser) {
      throw new Error("账号已存在，请重新输入");
    }

    // 设置默认头像路径（如果未提供 imgUrl）
    const imgUrl = userData.imgUrl || "http://localhost:5000/images/peoples/员工.png";

    // 调用数据访问层创建用户
    const userId = await User.createUser(
      userData.name,
      userData.pwd,
      userData.age,
      userData.gender,
      userData.address,
      userData.QQ,
      imgUrl // 使用设置的默认头像
    );

    return userId;
  } catch (err) {
    console.error("Error creating user:", err.message);
    throw err;
  }
};

// 更新用户
exports.updateUser = async (userData) => {
  try {
    // 查询用户是否存在
    const existingUser = await User.getUserById(userData.id);
    if (!existingUser) {
      throw new Error("用户不存在！");
    }

    // 如果未提供 imgUrl，使用默认头像
    const imgUrl = userData.imgUrl || existingUser.imgUrl;

    // 调用数据访问层更新用户
    await User.updateUser(
      userData.id,
      userData.name,
      userData.pwd,
      userData.age,
      userData.gender,
      userData.address,
      userData.QQ,
      imgUrl
    );
  } catch (err) {
    console.error(`Error updating user with ID ${userData.id}:`, err.message);
    throw err;
  }
};

exports.updateUserAge = async (id, age) => {
  try {
    const user = await User.getUserById(id);
    if (!user) {
      throw new Error("用户不存在");
    }
    await User.updateUserAge(id, age);
  } catch (err) {
    throw err;
  }
};


// 删除用户
exports.deleteUser = async (userId) => {
  try {
    await User.deleteUser(userId);
  } catch (err) {
    console.error(`Error deleting user with ID ${userId}:`, err.message);
    throw err;
  }
};

exports.updatePassword = async (id, newPassword) => {
  try {
    const user = await User.getUserById(id);
    if (!user) {
      throw new Error("用户不存在");
    }
    await User.updatePassword(id, newPassword);
  } catch (err) {
    throw err;
  }
};

exports.updateQQ = async (id, newQQ) => {
  try {
    const user = await User.getUserById(id);
    if (!user) {
      throw new Error("用户不存在");
    }
    await User.updateQQ(id, newQQ);
  } catch (err) {
    throw err;
  }
}
