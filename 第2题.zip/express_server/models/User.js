const { createPool } = require("mysql2/promise");

const dbConfig = require("../config/dbConfig");

const pool = createPool(dbConfig);

class User {
  constructor(id, name, pwd, age, gender, address, QQ, imgUrl) {
    this.id = id;
    this.name = name;
    this.pwd = pwd;
    this.age = age;
    this.gender = gender;
    this.address = address;
    this.QQ = QQ;
    this.imgUrl = imgUrl;
  }
  // 获取所有用户
  static async getUsers() {
    try {
      const [rows] = await pool.query("SELECT * FROM wyhtable1");
      if (rows.length === 0) {
        // user是null  
        return null;
      }
      // 将结果映射为 User类型的对象数组
      return rows.map(
        (row) =>
          new User(
            row.id,
            row.name,
            row.pwd,
            row.age,
            row.gender,
            row.address,
            row.QQ,
            row.imgUrl
          )
      );
    } catch (err) {
      console.error("Error fetching users:", err.message);
      throw err;
    }
  }

  static async getUserByName(name) {
    try {
      const [rows] = await pool.query("select * from wyhtable1 where name = ?", [
        name,
      ]);
      if (rows.length === 0) {
        // user是null  账号不存在
        return null;
      }
      return new User(
        rows[0].id,
        rows[0].name,
        rows[0].pwd,
        rows[0].age,
        rows[0].gender,
        rows[0].address,
        rows[0].QQ,
        rows[0].imgUrl
      );
    } catch (err) {
      // await失败时，处理错误，抛出异常  由调用者 await User.getUserByName() 捕获，继而再catch处理
      // 测试: stu -st
      console.error(`Error fetching user with Name ${name}:`, err.message);
      throw err;
    }
  }

  static async getUserById(id) {
    try {
      const [rows] = await pool.query("SELECT * FROM wyhtable1 WHERE id = ?", [id]);
      if (rows.length === 0) {
        // user是null
        return null;
      }
      return new User(
        rows[0].id,
        rows[0].name,
        rows[0].pwd,
        rows[0].age,
        rows[0].gender,
        rows[0].address,
        rows[0].QQ,
        rows[0].imgUrl
      );
    } catch (err) {
      console.error(`Error fetching user with ID ${id}:`, err.message);
      throw err;
    }
  }

  static async getUserByQQ(QQ) {
    try {
      const [rows] = await pool.query("SELECT * FROM wyhtable1 WHERE QQ = ?", [QQ]);
      if (rows.length === 0) {
        // 用户不存在
        return [];
      }
      return rows; // 返回所有匹配记录
    } catch (err) {
      console.error(`Error fetching users with QQ ${QQ}:`, err.message);
      throw err;
    }
  }



  static async createUser(name, pwd, age, gender, address, QQ, imgUrl) {
    try {
      const [result] = await pool.query(
        "INSERT INTO wyhtable1 (name, pwd, age, gender, address,QQ,imgUrl) VALUES (?, ?, ?, ?, ?, ?,?)",
        [name, pwd, age, gender, address, QQ, imgUrl]
      );
      return result.insertId;
      // 返回新插入记录的 ID
    } catch (err) {
      console.error("Error creating user:", err.messager);
      throw err;
    }
  }

  static async updateUser(id, name, pwd, age, gender, address, QQ, imgUrl) {
    try {
      await pool.query(
        "UPDATE wyhtable1 SET name = ?, pwd = ?, age = ? , gender = ?, address = ?, QQ= ?, imgUrl = ? WHERE id = ?",
        [name, pwd, age, gender, address, QQ, imgUrl, id]
      );
      // 木有返回值
    } catch (err) {
      console.error(`Error updating user with ID ${id}:`, err.message);
      throw err;
    }
  }

  static async updateUserAge(id, age) {
    try {
      const [result] = await pool.query("UPDATE wyhtable1 SET age = ? WHERE id = ?", [age, id]);
      return result.affectedRows > 0;
    } catch (err) {
      console.error("Error updating age:", err.message);
      throw err;
    }
  }


  static async deleteUser(id) {
    try {
      await pool.query("DELETE FROM wyhtable1 WHERE id = ?", [id]);
      // 木有返回值
    } catch (err) {
      console.error(`Error deleting user with ID ${id}:`, err.message);
      throw err;
    }
  }

  static async updatePassword(id, newPassword) {
    try {
      const [result] = await pool.query("UPDATE wyhtable1 SET pwd = ? WHERE id = ?", [newPassword, id]);
      return result.affectedRows > 0;
    } catch (err) {
      console.error("Error updating password:", err.message);
      throw err;
    }
  }

  static async updateQQ(id, newQQ) {
    try {
      const [result] = await pool.query("UPDATE wyhtable1 SET QQ = ? WHERE id = ?", [newQQ, id]);
      return result.affectedRows > 0;
    } catch (err) {
      console.error("Error updating QQ:", err.message);
      throw err;
    }
  }
}

module.exports = User;
