const { createPool } = require("mysql2/promise");

const dbConfig = require("../config/dbConfig");

const pool = createPool(dbConfig);

class Movie {
  constructor(id, filmId, name, description, posterUrl, popularity) {
    this.id = id;
    this.filmId = filmId;
    this.name = name;
    this.description = description;
    this.posterUrl = posterUrl;
    this.popularity = popularity;
  }

  // 获取所有电影
  static async getMovies() {
    try {
      const [rows] = await pool.query("SELECT * FROM wyhtable2");
      if (rows.length === 0) {
        // user是null  
        return null;
      }
      // 将结果映射为 Movie类型的对象数组
      return rows.map(
        (row) =>
          new Movie(
            row.id,
            row.filmId,
            row.name,
            row.description,
            row.posterUrl,
            row.popularity
          )
      );
    } catch (err) {
      console.error("Error fetching movies:", err.message);
      throw err;
    }
  }

  static async getMovieByName(name) {
    try {
      const [rows] = await pool.query("select * from wyhtable2 where name = ?", [
        name,
      ]);
      if (rows.length === 0) {
        // movie是null  电影不存在
        return null;
      }
      return new Movie(
        rows[0].id,
        rows[0].filmId,
        rows[0].name,
        rows[0].description,
        rows[0].posterUrl,
        rows[0].popularity
      );
    } catch (err) {
      // await失败时，处理错误，抛出异常  由调用者 await Movie.getMovieByName() 捕获，继而再catch处理
      // 测试:  movie -movie
      console.error(`Error fetching movie with Name ${name}:`, err.message);
      throw err;
    }
  }

  static async getMovieById(id) {
    try {
      const [rows] = await pool.query("SELECT * FROM wyhtable2 WHERE id = ?", [id]);
      if (rows.length === 0) {
        // movie是null
        return null;
      }
      return new Movie(
        rows[0].id,
        rows[0].filmId,
        rows[0].name,
        rows[0].description,
        rows[0].posterUrl,
        rows[0].popularity
      );
    } catch (err) {
      console.error(`Error fetching movie with ID ${id}:`, err.message);
      throw err;
    }
  }

  static async createMovie(filmId, name, description, posterUrl, popularity) {
    try {
      const [result] = await pool.query(
        "INSERT INTO wyhtable2 (filmId, name, description, posterUrl, popularity) VALUES (?, ?, ?, ?, ?)",
        [filmId, name, description, posterUrl, popularity]
      );
      return result.insertId;
      // 返回新插入记录的 ID
    } catch (err) {
      console.error("Error creating movie:", err.messager);
      throw err;
    }
  }
  static async updateMovie(id, filmId, name, description, posterUrl, popularity) {
    try {
      await pool.query(
        "UPDATE wyhtable2 SET filmId = ?, name = ?, description = ?, posterUrl = ?, popularity = ? WHERE id = ?",
        [filmId, name, description, posterUrl, popularity, id]
      );
      // 木有返回值
    } catch (err) {
      console.error(`Error updating movie with ID ${id}:`, err.message);
      throw err;
    }
  }

  static async deleteMovie(id) {
    try {
      await pool.query("DELETE FROM wyhtable2 WHERE id = ?", [id]);
      // 木有返回值
    } catch (err) {
      console.error(`Error deleting movie with ID ${id}:`, err.message);
      throw err;
    }
  }

  static async addPopularityById(id) {
    try {
      await pool.query("UPDATE wyhtable2 SET popularity = popularity + 1 WHERE id = ?", [id]);
    } catch (err) {
      console.error(`Error adding popularity to movie with ID ${id}:`, err.message);
      throw err;
    }
  }
}

module.exports = Movie;
