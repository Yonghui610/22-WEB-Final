<template>
    <ul class="header">
        <router-link custom v-for="item in items" :to="item.to" #="{ isActive, navigate }">
            <li @click="navigate">
                <span :class="isActive ? 'gljactive' : ''">{{ item.label}}</span>
            </li>
        </router-link>
    </ul>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router';

const props = defineProps({
    items: {
        type: Array,
        required: true
    }
});

</script>

<style scoped lang="scss">
.header {
    display: flex;
    height: 50px;
    line-height: 50px;
    text-align: center;

    li {
        flex: 1;

        span {
            padding: 10px 0;
        }
    }
}

.gljactive {
    color: red;
    border-bottom: 3px solid red;
}
</style>



