const userManageRoutes = [
  {
    path: "/usermanagelogin",
    name: "usermanagelogin",
    component: () => import("@/views/users/UsersManageLogin.vue"),
    meta: {
      title: "用户管理中心--登录/注册",
    },
  },

  {
    path: "/userscenter",
    name: "userscenter",
    component: () => import("@/views/users/UsersCenter.vue"),
    meta: {
      title: "用户中心",
      requiredAuth: true,
    },
    beforeEnter: (to, from) => {
      let isAuthenticated = localStorage.getItem("token");
      if (!isAuthenticated) return { name: "usermanagelogin" };
      return true;
    },
    children: [
      {
        path: "/userscenter",
        redirect: "/userscenter/userselect",
      },
      {
        path: "userselect",
        name: "userselect",
        component: () => import("@/views/users/crud/Select.vue"),
        meta: {
          title: "用户中心--用户查询",
          requiredAuth: true,
        },
      },
      {
        path: "usercreate",
        name: "usercreate",
        component: () => import("@/views/users/crud/Create.vue"),
        meta: {
          title: "用户中心--用户创建",
          requiredAuth: true,
        },
      },
      {
        path: "userdelete",
        name: "userdelete",
        component: () => import("@/views/users/crud/Delete.vue"),
        meta: {
          title: "用户中心--用户删除",
          requiredAuth: true,
        },
      },
      {
        path: "usermodify",
        name: "usermodify",
        component: () => import("@/views/users/crud/Modify.vue"),
        meta: {
          title: "用户中心--用户修改",
          requiredAuth: true,
        },
      },
      {
        path: "selectByQQ",
        name: "selectByQQ",
        component: () => import("@/views/users/crud/SelectByQQ.vue"),
        meta: {
          title: "用户中心--用户查询",
          requiredAuth: true,
        },
      },
    ],
  },
];

export default userManageRoutes;
