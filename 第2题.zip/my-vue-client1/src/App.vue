<template>
    <div>
        <router-view />
        <Tabbar v-if="isLoggedIn"/>
    </div>
</template>

<script setup>
import Tabbar from '@/components/Tabbar.vue'
import { provide, ref } from 'vue'
const isLoggedIn = ref(true);

// Tabbar消失
const login = () => {
    isLoggedIn.value = false;
};

//Tabbar出现
const logout = () => {
    isLoggedIn.value = true;
};

provide('login', login);
provide('logout', logout);

// 例如 UsersCenter.vue 中注入

</script>
<style>


ul {
    list-style: none;
}
</style>
