<template>
    <div class="container">
      <!-- 无数据，不显示表头 -->
      <template v-if="isShow">
        <table>
          <caption>电影列表</caption>
          <thead>
            <tr>
              <th>序号</th>
              <th>电影ID</th>
              <th>电影名称</th>
              <th>电影海报</th>
              <th>电影评分</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="item in datalist" :key="item.id">
              <td>{{ item.id }}</td>
              <td>{{ item.filmId }}</td>
              <td>{{ item.name }}</td>
              <td><img :src="item.posterUrl" alt="海报" /></td>
              <td>{{ item.popularity }}</td>
            </tr>
          </tbody>
        </table>
      </template>
      <template v-else>
        <p>暂无数据</p>
      </template>
      <p v-if="error" class="error-message">{{ error }}</p>
    </div>
  </template>
  
  <script setup>
  import { ref, computed, onMounted } from "vue";
  import axios from "axios";
  import { useRoute } from "vue-router";
  
  const route = useRoute();
  const datalist = ref([]);
  const isShow = ref(false); // 是否显示表格表头
  const error = ref('');    // 错误信息
  const token = localStorage.getItem("token");
  const isAdmin = localStorage.getItem("isAdmin");
  const userInfo = JSON.parse(localStorage.getItem("userInfo"));

  
  const fetchData = async (url) => {
    try {
      const res = await axios({
        method: "GET",
        url,
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (res.data.success) {
        isShow.value = true;
        datalist.value = res.data.data.films.slice(0,10).sort((a, b) => b.filmId - a.filmId);
        //datalist.value= datalist.value
      } else {
        isShow.value = false;
        throw new Error(res.data.message);
      }
    } catch (err) {
      error.value = err;
    }
  };
  
  onMounted(() => {
    if (isAdmin==='true') {
      fetchData("http://localhost:5000/movies/movies");
    } else {

    }
  });
  </script>
  
  <style scoped>
  .container {
    width: 80%;
    margin: 0 auto;
    text-align: center;
  }
  
  table {
    border-collapse: collapse;
    width: 100%;
  }
  
  td,
  th {
    font-size: 18px;
    text-align: center;
    border: 1px solid #000;
  }
  
  caption {
    font-size: 20px;
    font-weight: bold;
  }
  
  img {
    width: 35px;
  }
  
  .error-message {
    color: red;
    margin-top: 10px;
  }
  </style>
  