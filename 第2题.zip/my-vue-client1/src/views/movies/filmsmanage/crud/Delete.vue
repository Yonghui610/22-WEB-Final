<template>
    <div class="container">
        <!-- 无数据，不显示表头 -->
        <template v-if="isShow">

            <table>
                <caption>电影列表</caption> 
                <thead>
                    <tr>
                        <th>序号</th>
                        <th>电影ID</th>
                        <th>电影名称</th>
                        <!-- <th>电影描述</th> -->
                        <th>电影评分</th>
                        <th>电影图片</th>
                        <th>操作</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="item in datalist" :key="item.id">
                        <td>{{ item.id }}</td>
                        <td>{{ item.filmId }}</td>
                        <td>{{ item.name }}</td>
                        <!-- <td>{{ item.description }}</td> -->
                        <td>{{ item.popularity }}</td>
                        <td><img :src="item.posterUrl" alt="电影图片"></td>
                        <td><button @click="deleteData(item.id)">删除</button></td>
                    </tr>
                </tbody>
            </table>

        </template>
        <template v-else>
            <p>暂无数据</p>
        </template>

        <p v-if="error" class="error-message">{{ error }}</p>
    </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";

const datalist = ref([]);
const isShow = ref(true);
const error = ref('');
const token = localStorage.getItem("token");
// 获取数据的辅助函数
const fetchData = async () => {
    try {
        const res = await axios({
            method: "GET",
            url: "http://localhost:5000/movies/movies",
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });
        if (res.data.success) {
        datalist.value = res.data.data.films.slice(-1)
        //datalist.value = res.data.data.films;

        } else {
            isShow.value = false;
            throw new Error(res.data.message);
        }
    } catch (err) {
        error.value = err;
    }
};

onMounted(fetchData);

const deleteData = async (id) => {
    try {
        const res = await axios({
            method: "DELETE",
            url: `http://localhost:5000/movies/movies/${id}`,
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });
        if (res.data.success) {
            alert("删除成功！");
            await fetchData(); // 刷新数据列表
        } else {
            throw new Error(res.data.message);
        }
    } catch (err) {
        error.value = err;
    }
};
</script>

<style>
.container {
    width: 80%;
    margin: 0 auto;
    text-align: center;
}

table {
    border-collapse: collapse;
    width: 100%;
}

td,
th {
    font-size: 18px;
    text-align: center;
    border: 1px solid #000;
}

caption {
    font-size: 20px;
    font-weight: bold;
}

img {
    width: 35px;
}

button {
    padding: 10px 20px;
    background-color:yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

.error-message {
    color: red;
    margin-top: 10px;
}
</style>
