<!-- MovieTabbar 组件 -->
<template>
    <div>
        <button @click="handleExit">退出</button>
        <h3>欢迎进入电影管理中心</h3>

        <MovieTabbar :items="tabItems" />

        <router-view />
    </div>
</template>

<script setup>
import MovieTabbar from '@/components/MovieTabbar.vue' 
import { ref, computed, inject } from 'vue';
import { useRoute, useRouter } from 'vue-router';
// 已登录，让Tabbar消失
const login = inject('login');
login();
const logout = inject('logout');

const userInfo = JSON.parse(localStorage.getItem("userInfo"));
const isAdmin = localStorage.getItem("isAdmin");

const route = useRoute();
const router = useRouter();

router.push({
    name: 'filmselect',
})

const tabItems = computed(() => {
    if (isAdmin==='true') {
        return [
            {
                label: '全部电影详细信息',
                to: { name: 'filmselect', params: { id: route.params.iddata } }
            },
            {
                label: '创建新电影',
                to: { name: 'filmcreate' }
            },
            {
                label: '删除违规电影',
                to: { name: 'filmdelete' }
            },
            {
                label: '修改电影信息',
                to: { name: 'filmmodify', params: { id: route.params.iddata } }
            }
        ];
    } else {
        return [
            {
                label: '暂无权限',
                to: { name: 'filmselect', params: { id: route.params.iddata } }
            },
            {
                label: '等待完善',
                to: { name: 'filmmodify', params: { id: route.params.iddata } }
            }
        ];
    }
});
const handleExit = () => {
    const answer = window.confirm("你确定要离开吗？")
    if (answer) {
        localStorage.clear();
        // 恢复Tabbar
        logout();
        router.push("/")
        return true;
    } else {
        return false;
    }
}

</script>
