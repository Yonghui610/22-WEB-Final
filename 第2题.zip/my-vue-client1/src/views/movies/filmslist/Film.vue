<template>
    <div>
        <button @click="handleBack">返回</button>

        <h3>猜你喜欢</h3>
        <ul>
            <li @click="handleClick">电影1</li>
        </ul>
        <br>
        <div>
<!-- 考试要是增加别的字段在这里加 -->
            <!-- <h2>{{ datalist.name}}</h2>
            <img :src="datalist.poster" :width=200 alt="海报"></img>
            <p>主演：<span v-for="item in datalist.actors"> {{ item.name }}、</span></p>
            <p>类型：{{ datalist.category}}</p>
            <p>上映时间：{{ datalist.premiereAt}}</p>
            <p>评分：{{ datalist.grade}}</p>
            <p>片长：{{ datalist.runtime}}</p>
            <p>剧情：{{ datalist.synopsis}}</p> -->
            <!--  访问本地的数据库时，显示name、description、posterUrl、popularity 即可 -->

            <h2>{{ dataDetail.name}}</h2>
            <img :src="dataDetail.posterUrl" :width=200 alt="海报" />
            <p>剧情：{{ dataDetail.description}}</p>
            <p>评分：{{ dataDetail.popularity}}</p>
        </div>
    </div>
</template>

<script  setup>
import { ref, onMounted, watch} from 'vue'
import { useRouter, useRoute, onBeforeRouteUpdate } from 'vue-router';
import axios from "axios"
const router = useRouter();
const route = useRoute();
const dataDetail = ref({}) 
const id = route.params.iddata;

onMounted(async (e) => {
    getMovies(id);
})

const getMovies = async (id) => {
    const res = await axios({
        url: "http://localhost:5000/movies/movies/"+id,
    })
    console.log()
    if(res.data.code==200){
        dataDetail.value = res.data.data
    }
}

const handleBack = () => {
    router.push("/")
}

const handleClick = () => {
    router.push({
        name: "film",
        params: { iddata: 6640 }
    })
}


watch(() => route.params.iddata, async (newId) => {
    console.log("接受'猜你喜欢'传来的参数", newId, "带着新id参数请求后端接口")
    try {
        const res = await axios({
            url: "https://m.maizuo.com/gateway?filmId=" + newId + "&k=4129458",
            headers: {
                'X-Client-Info': '{"a":"3000","ch":"1002","v":"5.2.1","e":"17209289107592677545607169","bc":"120100"}',
                'X-Host': 'mall.film-ticket.film.info'
            }
        })
        datalist.value = res.data.data.film
    } catch (err) {
        console.log("出错了！", err);
    }
})
</script>

<style>
button {
    padding: 10px 20px;
    background-color:yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}
button:hover {
    background-color: #0056b3;
}
</style>


