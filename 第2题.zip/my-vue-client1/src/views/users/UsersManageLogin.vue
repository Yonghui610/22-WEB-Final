<template>
    <div class="login">
        <h4>用户管理中心登录页</h4>
        <template v-if="!isRegister">
            <form>
                用户名：<input v-model="name" />
                <br>
                密码：<input type="password" v-model="pwd" />
                <br>
                QQ号：<input v-model="QQ" />
                <br>
                <button type="button" @click="handleLogin">登录</button>
            </form>
        </template>
        <template v-else>
            <form>
                用户名：<input v-model="name" />
                <br>
                密码：<input type="password" v-model="pwd" />
                <br>
                年龄：<input type="number" v-model="age" />
                <br>
                性别：<input v-model="gender" type="radio" name="gender" value="男" />男
                <input v-model="gender" type="radio" name="gender" value="女" />女<br>
                地址：<input type="text" v-model="address" />
                <br>
                QQ号：<input type="text" v-model="QQ" />
                <br>
                <button type="button" @click="confirmRegister">注册</button>        
            </form>
        </template>
        <button v-if="!isRegister" type="button" @click="handleRegister">没有账号？去注册</button>
        <button v-else type="button" @click="handleRegister">返回登录</button>
        <p v-if="error" class="error-message">{{ error }}</p>
    </div>
</template>
    
<script setup>
import axios from 'axios'
import { useRouter } from 'vue-router';
const router = useRouter();
import { ref } from 'vue'

const name = ref("")
const pwd = ref('')
const age = ref('')
const gender = ref('')
const QQ=ref('')
const address = ref('')
const error = ref('');
const isRegister = ref(false);
const handleLogin = async () => {
    try {
        const res = await axios({
            method: "POST",
            url: "http://localhost:5000/stus/login",
            data: {
                name: name.value,
                pwd: pwd.value,
                QQ: QQ.value,
            }
        })
        if (res.data.success) {
            localStorage.setItem("token", res.data.data.token)
            let isAdmin = res.data.data.nickname=='管理员'?true:false
            localStorage.setItem("isAdmin", isAdmin)
            let userInfo = res.data.data.data;
            localStorage.setItem("userInfo", JSON.stringify(userInfo))
            //登录成功，跳转到userscenter
            router.push({
                name: "userscenter",
            })
        } else {
            throw (res.data.message)
        }
    } catch (err) {
        error.value = err;
    }
    }
const confirmRegister = async () => {
    if (name.value === '' || pwd.value === '' || age.value === '' || gender.value === '' || address.value === ''|| QQ.value==='') {
        error.value = '请填写完整信息';
        return;
    }
    try {
        const res = await axios({
            method: "POST",
            url: "http://localhost:5000/stus/register",
            data: {
                name: name.value,
                pwd: pwd.value,
                age: age.value,
                gender: gender.value,
                address: address.value,
                QQ:QQ.value,
            }
        })
        if (res.data.success) {
             console.log('Register Response Data:', res.data.data); // 打印注册响应数据
            localStorage.setItem("token", res.data.data.token)
            let isAdmin = res.data.data.nickname=='管理员'?true:false
            localStorage.setItem("isAdmin", isAdmin)
            let userInfo = res.data.data.data;
            localStorage.setItem("userInfo", JSON.stringify(userInfo))
            console.log('User Info:', userInfo);

            router.push({
                name: "userscenter"
            })
        } else {
            throw (res.data.message)
        }
    } catch (err) {
        error.value = err;
    }
}
const handleRegister = () => {
    isRegister.value = !isRegister.value;
    name.value = '';
    pwd.value = '';
    age.value = '';
    gender.value = "男";
    address.value = '';
    QQ.value='';
}
</script> 

<style scoped>
.login {
    padding-top: 50px;
    width: 100%;
    height: 40px;
    line-height: 40px;
    text-align: center;

}

button {
    padding: 10px 20px;
    margin-top: 20px;
    background-color: yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #008c8c;
}

.error-message {
    color: red;
    margin-top: 10px;
}
</style>

