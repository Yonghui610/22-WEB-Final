<template>
  <div class="container">
    <!-- 查询栏 -->
    <div class="search-bar">
      <input type="text" v-model="QQ" placeholder="请输入QQ号" />&nbsp
      <button type="button" @click="searchUser">查询用户</button>
    </div>

    <!-- 查询结果 -->
    <template v-if="showResult">
      <table v-if="datalist.length > 0">
        <caption>查询结果</caption>
        <thead>
          <tr>
            <th>学号</th>
            <th>姓名</th>
            <th>密码</th>
            <th>年龄</th>
            <th>性别</th>
            <th>地址</th>
            <th>QQ号</th>
            <th>头像</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in datalist" :key="item.id">
            <td>{{ item.id }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.pwd }}</td>
            <td>{{ item.age }}</td>
            <td>{{ item.gender }}</td>
            <td>{{ item.address }}</td>
            <td>{{ item.QQ }}</td>
            <td>
              <img
                :src="item.imgUrl || 'http://localhost:5000/images/peoples/员工.png'"
                alt="头像"
                class="avatar"
              />
            </td>
          </tr>
        </tbody>
      </table>
      <p v-else-if="error" class="error-message">{{ error }}</p>
      <!-- <p v-else class="no-data">未查询到用户信息。</p> -->
    </template>
  </div>
</template>

<script setup>
import { ref } from "vue";
import axios from "axios";

// 声明变量
const QQ = ref(""); // QQ号输入框绑定
const datalist = ref([]); // 查询到的用户数据列表
const error = ref(""); // 错误信息
const showResult = ref(false); // 控制是否显示结果区域

// 查询用户方法
const searchUser = async () => {
  // 清空上次查询结果
  datalist.value = [];
  error.value = "";
  showResult.value = false;

  if (!QQ.value) {
    alert("请输入QQ号！");
    return;
  }

  try {
    const token = localStorage.getItem("token");
    const res = await axios({
      method: "GET",
      url: `http://localhost:5000/stus/users/qq/${QQ.value}`,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    showResult.value = true; // 用户点击查询后，显示结果区域

    if (res.data.success && res.data.data.length > 0) {
      datalist.value = res.data.data; // 更新查询到的用户数据
    } else {
      error.value = "Error：未查询到用户信息，获取用户数据失败！";
    }
  } catch (err) {
    console.error("查询失败：", err);
    error.value = "查询失败，请检查网络或接口！";
    showResult.value = true; // 即使失败也显示错误信息
  }
};
</script>

<style scoped>
.container {
  width: 80%;
  margin: 0 auto;
  text-align: center;
}

.search-bar {
  margin-bottom: 20px;
  text-align: center;
}

table {
  border-collapse: collapse;
  width: 100%;
  margin-top: 20px;
}

td,
th {
  font-size: 16px;
  text-align: center;
  border: 1px solid #000;
  padding: 5px;
}

caption {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
}

img.avatar {
  width: 50px;
  height: 50px;
  object-fit: cover;
  border-radius: 50%;
}

.error-message {
  color: red;
  text-align: center;
  margin-top: 20px;
}

.no-data {
  text-align: center;
  color: gray;
  margin-top: 20px;
}
</style>
