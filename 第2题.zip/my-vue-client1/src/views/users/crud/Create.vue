<template>
    <div class="login">
        <form>
            用户名：<input v-model="name" /><br>
            密码：<input type="password" v-model="pwd" /><br>
            年龄：<input type="number" v-model="age" /><br>
            <input v-model="gender" type="radio" name="gender" value="男" />男
            <input v-model="gender" type="radio" name="gender" value="女" />女<br>
            地址：<input v-model="address" /><br>
            QQ号：<input v-model="QQ" /><br>
            <button type="button" @click="handleCreate">创建新用户</button>
        </form>

        <p v-if="error" class="error-message">{{ error }}</p>
    </div>
</template>

<script setup>
import axios from 'axios';
import { ref } from 'vue';

const name = ref("")
const pwd = ref('')
const age = ref('')
const gender = ref("男")
const QQ = ref('')
const address = ref('')

const error = ref('');
const handleCreate = async () => {
    // 验证表单
    if (!validateForm()) return;

    try {
        const token = localStorage.getItem("token");
        const res = await axios({
            method: "POST",
            url: "http://localhost:5000/stus/users",
            headers: {
                "Authorization": `Bearer ${token}`
            },
            data: {
                name: name.value,
                pwd: pwd.value,
                age: age.value,
                gender: gender.value,
                address: address.value,
                QQ:QQ.value,
            }
        });

        if (res.data.success) {
            alert(res.data.message);
        } else {
            throw new Error(res.data.message);
        }
    } catch (err) {
        error.value = err;
    }
};

// 验证表单
const validateForm = () => {
    if (!name.value || !pwd.value || !age.value || !gender.value || !address.value||!QQ.value) {
        alert("请确保所有字段都已填写！");
        return false;
    }
    return true;
};
</script>

<style scoped>
.login {
    padding-top: 50px;
    width: 80%;
    margin: 0 auto;
    text-align: center;
}

button {
    padding: 10px 20px;
    margin-top: 20px;
    background-color: yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

.error-message {
    color: red;
    margin-top: 10px;
}
</style>