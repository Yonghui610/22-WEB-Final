<template>
  <div class="modify">
    <!-- 有数据时，显示修改表单 -->
    <template v-if="isShow">
      <form>
        <ul>
          <li v-for="(item, index) in datalist" :key="item.id" class="form-row">
            用户名：<input v-model="item.name" />
            密码：<input type="password" v-model="item.pwd" />
            年龄：<input type="number" v-model="item.age" />
            性别：
            <input v-model="item.gender" type="radio" value="男" />男
            <input v-model="item.gender" type="radio" value="女" />女
            地址：<input v-model="item.address" />&nbsp
            QQ号：<input v-model="item.QQ" />&nbsp
            <button type="button" @click="modifyData(item.id, index)">修改</button>
          </li>
        </ul>
      </form>
    </template>
    <!-- 无数据时显示 -->
    <template v-else>
      <p>暂无数据</p>
    </template>

    <p v-if="error" class="error-message">{{ error }}</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useRoute } from "vue-router";

// 路由和状态
const route = useRoute();
const isShow = ref(true); // 数据是否显示
const error = ref(""); // 错误信息
const token = localStorage.getItem("token"); // 获取本地存储的 token
const isAdmin = localStorage.getItem("isAdmin"); // 判断是否是管理员
const userInfo = JSON.parse(localStorage.getItem("userInfo")); // 当前用户信息
let datalist = ref([]); // 数据列表

// 获取数据
const fetchData = async () => {
  try {
    let url =
      isAdmin === "true"
        ? "http://localhost:5000/stus/users"
        : `http://localhost:5000/stus/users/${userInfo.id}`;
    const res = await axios({
      method: "GET",
      url,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (res.data.success) {
      datalist.value = isAdmin === "true" ? res.data.data : [res.data.data]; // 普通用户显示自己数据
    } else {
      isShow.value = false;
      throw new Error(res.data.message);
    }
  } catch (err) {
    error.value = err.message || "数据加载失败";
  }
};

// 修改数据
const modifyData = async (id, index) => {
  try {
    const user = datalist.value[index];
    const res = await axios({
      method: "PUT",
      url: `http://localhost:5000/stus/users`, // 根据后端逻辑，去掉 :id
      headers: {
        Authorization: `Bearer ${token}`,
      },
      data: {
        id: id, // 将 id 放到请求体中
        name: user.name,
        pwd: user.pwd,
        age: user.age,
        gender: user.gender,
        address: user.address,
        QQ: user.QQ,
      },
    });

    if (res.data.success) {
      alert("用户信息修改成功！");
    } else {
      throw new Error(res.data.message);
    }
  } catch (err) {
    error.value = err.message || "修改失败";
  }
};

// 页面挂载时加载数据
onMounted(() => {
  fetchData();
});
</script>
<style scoped>
ul {
    list-style: none;
}

.modify {
    padding-top: 50px;
    width: 100%;
    margin: 0 auto;
    text-align: center;
}

button {
    padding: 10px 20px;
    background-color: yellowgreen;
    margin-bottom: 15px;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
.error-message {
    color: red;
    margin-top: 10px;
}
</style>
