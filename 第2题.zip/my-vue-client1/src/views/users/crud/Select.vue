<template>
  <div class="container">
    <template v-if="isShow">
      <table>
        <caption>学生列表</caption>
        <thead>
          <tr>
            <th>学号</th>
            <th>姓名</th>
            <th>密码</th>
            <th>年龄</th>
            <th>性别</th>
            <th>地址</th>
            <th>QQ号</th>
            <th>头像</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item, index) in datalist" :key="item.id">
            <td>{{ item.id }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.pwd }}
              <div>
                <button @click="openPasswordForm(item)">修改密码</button>
              </div>
            </td>
            <td>
              {{ item.age }}
              <div>
                <button @click="updateAge(item.id, index, 1)">增加</button>&nbsp
                <button @click="updateAge(item.id, index, -1)">减少</button>
              </div>
            </td>
            <td>{{ item.gender }}</td>
            <td>{{ item.address }}</td>
            <td>{{ item.QQ }}
             <div>
                <button @click="openQQForm(item)">修改QQ</button>
              </div>
            </td>
            <td>
              <img :src="item.imgUrl || 'http://localhost:5000/images/peoples/员工.png'" alt="头像" />
            </td>
          </tr>
        </tbody>
      </table>
    </template>
    <template v-else>
      <p>暂无数据</p>
    </template>

    <!-- 修改密码表单 -->
    <div v-if="selectedUser" class="password-form">
      <h3>修改密码</h3>
      <form @submit.prevent="changePassword">
        <div>
          <label for="originalPassword">原密码：</label>
          <input id="originalPassword" type="password" :value="selectedUser.pwd" readonly />
        </div>
        <div>
          <label for="newPassword">新密码：</label>
          <input id="newPassword" v-model="newPassword" type="password" required />
        </div>
        <div>
          <label for="confirmPassword">确认新密码：</label>
          <input id="confirmPassword" v-model="confirmPassword" type="password" required />
        </div>
        <p v-if="passwordError" class="error-message">{{ passwordError }}</p>
        <button type="submit">提交</button>
        <button type="button" @click="cancelPasswordChange">取消</button>
      </form>
    </div>

    <!-- 修改密码表单 -->
    <div v-if="selectedQQUser" class="password-form">
      <h3>修改密码</h3>
      <form @submit.prevent="changeQQ">
        <div>
          <label for="originalQQ">原QQ：</label>
          <input id="originalQQ" type="text" :value="selectedQQUser.QQ" readonly />
        </div>
        <div>
          <label for="newQQ">新QQ：</label>
          <input id="newQQ" v-model="newQQ" type="text" required />
        </div>
        <div>
          <label for="confirmQQ">确认新QQ：</label>
          <input id="confirmQQ" v-model="confirmQQ" type="text" required />
        </div>
        <p v-if="QQError" class="error-message">{{ QQError }}</p>
        <button type="submit">提交</button>
        <button type="button" @click="cancelQQChange">取消</button>
      </form>
    </div>
    <p v-if="error" class="error-message">{{ error }}</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";

const datalist = ref([]); // 用户数据列表
const isShow = ref(true); // 是否显示表格
const error = ref(""); // 错误信息
const token = localStorage.getItem("token"); // 获取本地存储的token
const isAdmin = localStorage.getItem("isAdmin"); // 是否为管理员，从localStorage获取
const userInfo = JSON.parse(localStorage.getItem("userInfo")); // 当前用户信息，从localStorage解析

const selectedUser = ref(null); // 当前选中用户，用于修改密码表单
const newPassword = ref(""); // 新密码
const confirmPassword = ref(""); // 确认密码
const passwordError = ref(""); // 用于存储密码不一致的错误信息

const selectedQQUser = ref(null); // 当前选中用户，用于修改qq表单
const newQQ = ref(""); // 新QQ
const confirmQQ = ref(""); // 确认QQ
const QQError = ref(""); // 用于存储QQ不一致的错误信息

// 获取用户数据
const fetchData = async () => {
  try {
    let url = "http://localhost:5000/stus/users";
    if (isAdmin !== "true") {
      const userId = userInfo?.id;
      if (!userId) {
        throw new Error("用户 ID 不存在，无法加载数据！");
      }
      url = `http://localhost:5000/stus/users/${userId}`;
      // 如果不是管理员，仅获取当前用户数据

    }

    const res = await axios({
      method: "GET",
      url,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (res.data.success) {
      if (isAdmin === "true") {
        // 如果是管理员，显示所有用户并按qq排序
        datalist.value = res.data.data.sort((a, b) => a.QQ - b.QQ);
      } else {
        // 如果是普通用户，只显示自己的数据
        datalist.value = [res.data.data];
      }
    } else {
      isShow.value = false;
      throw new Error(res.data.message);
    }
  } catch (err) {
    error.value = err.message || "获取数据失败";
  }
};

// 打开修改密码表单
const openPasswordForm = (user) => {
  selectedUser.value = user;
  newPassword.value = "";
  confirmPassword.value = "";
  passwordError.value = ""; // 清空错误信息
};

// 关闭修改密码表单
const cancelPasswordChange = () => {
  selectedUser.value = null;
  passwordError.value = ""; // 清空错误信息
};

// 提交修改密码请求
const changePassword = async () => {
  if (newPassword.value !== confirmPassword.value) {
    passwordError.value = "两次密码输入不一致！"; // 显示错误信息
    return;
  }
  try {
    const res = await axios({
      method: "PUT",
      url: "http://localhost:5000/stus/users/password",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      data: {
        id: selectedUser.value.id,
        newPassword: newPassword.value,
      },
    });

    if (res.data.success) {
      alert("密码修改成功！");
      selectedUser.value.pwd = newPassword.value; // 更新本地数据
      selectedUser.value = null; // 关闭表单
    } else {
      alert(res.data.message);
    }
  } catch (err) {
    alert("修改密码失败！");
  }
};

// 打开修改QQ表单
const openQQForm = (user) => {
  selectedQQUser.value = user;
  newQQ.value = "";
  confirmQQ.value = "";
  QQError.value = ""; // 清空错误信息
};

// 关闭修改QQ表单
const cancelQQChange = () => {
  selectedQQUser.value = null;
  QQError.value = ""; // 清空错误信息
};

// 提交修改QQ请求
const changeQQ = async () => {
  if (newQQ.value !== confirmQQ.value) {
    QQError.value = "两次QQ输入不一致！"; // 显示错误信息
    return;
  }

  try {
    const res = await axios({
      method: "PUT",
      url: "http://localhost:5000/stus/users/QQ",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      data: {
        id: selectedQQUser.value.id,
        newQQ: newQQ.value,
      },
    });

    if (res.data.success) {
      alert("QQ修改成功！");
      selectedQQUser.value.QQ = newQQ.value; // 更新本地数据
      fetchData()
      selectedQQUser.value = null; // 关闭表单
    } else {
      alert(res.data.message);
    }
  } catch (err) {
    alert("修改QQ失败！");
  }
};

// 更新年龄
const updateAge = async (id, index, delta) => {
  try {
    const newAge = datalist.value[index].age + delta;
    const res = await axios({
      method: "PUT",
      url: "http://localhost:5000/stus/users/age",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      data: { id, age: newAge },
    });
    if (res.data.success) {
      datalist.value[index].age = newAge;
    } else {
      alert(res.data.message);
    }
  } catch (err) {
    alert("更新年龄失败");
  }
};

onMounted(() => {
  fetchData();
});
</script>


<style scoped>
.container {
  width: 80%;
  margin: 0 auto;
  text-align: center;
}

table {
  border-collapse: collapse;
  width: 100%;
}

td,
th {
  font-size: 18px;
  text-align: center;
  border: 1px solid #000;
}

caption {
  font-size: 20px;
  font-weight: bold;
}

img {
  width: 35px;
}

.error-message {
  color: red;
  margin-top: 10px;
}

button {
  padding: 10px 10px;
  background-color: yellowgreen;
  margin-bottom: 15px;
  color: white;
  border: none;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}

.password-form {
  margin-top: 50px;
  /* 表单与表格间距 */
  text-align: center;
  /* 表单居中 */
}

.password-form form {
  display: inline-block;
  text-align: left;
}

.password-form div {
  margin-bottom: 10px;
}

.password-form button {
  margin-right: 10px;
}
</style>
