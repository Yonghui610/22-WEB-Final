<!-- UserTabbar 组件 -->
<template>
    <div>
        <button @click="handleExit">退出</button>
        <h3>欢迎进入用户管理中心</h3>

        <UserTabbar :items="tabItems" />

        <router-view />
    </div>
</template>

<script setup>
import UserTabbar from '@/components/UserTabbar.vue'
import { ref, computed, inject } from 'vue';
import { useRoute, useRouter } from 'vue-router';

// 已登录，让Tabbar消失
const login = inject('login');
login();
const logout = inject('logout');
const isAdmin = localStorage.getItem("isAdmin"); // 是否是管理员
const userInfo = JSON.parse(localStorage.getItem("userInfo"));
const route = useRoute();
const router = useRouter();

router.push({
    name: 'userselect',
})

const tabItems = computed(() => {
    console.log(isAdmin,'ISADMIN')
    if (isAdmin==='true') {
        return [
            {
                label: '全部用户详细信息',
                to: { name: 'userselect', params: { id: userInfo.id } }
            },
            {
                label: '创建新用户',
                to: { name: 'usercreate' }
            },
            {
                label: '删除违规用户',
                to: { name: 'userdelete' }
            },
            {
                label: '修改用户信息',
                to: { name: 'usermodify', params: { id: userInfo.id } }
            },
            {
                label: 'QQ号查询用户',
                to: { name: 'selectByQQ', params: { id: userInfo.QQ } }
            }
        ];
    } else {
        return [
            {
                label: '个人用户列表信息',
                to: { name: 'userselect' }
            },
            {
                label: '修改用户',
                to: { name: 'usermodify' }
            }
        ];
    }
});
console.log(tabItems.value)
const handleExit = () => {
    const answer = window.confirm("你确定要离开吗？")
    if (answer) {
        localStorage.clear();
        // 恢复Tabbar
        logout();
        router.push("/")
        return true;
    } else {
        return false;
    }
}

</script>