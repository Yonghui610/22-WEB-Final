const User = require("../models/User");

// 获取所有用户
exports.getUsers = async () => {
    try {
        const users = await User.getUsers();
        return users;
    } catch (err) {
        console.error("Error fetching users:", err);
        throw err;
    }
};

// 根据 name  获取单个用户
exports.getUserByName = async (userName) => {
    try {
        const user = await User.getUserByName(userName);
        if (!user) {
            return null;
        }
        return user;
    } catch (err) {
        console.error(`Error fetching user with Name and Pwd ${userName}:`, err);
        throw err;
    }
};


// 根据 ID 获取单个用户
exports.getUserById = async (userId) => {
    try {
        const user = await User.getUserById(userId);
        if (!user) {
            return null;
        }
        return user;
    } catch (err) {
        console.error(`Error fetching user with ID ${userId}:`, err);
        throw err;
    }
};

// 创建新用户
exports.createUser = async (userData) => {
    try {
        const userId = await User.createUser(
            userData.name,
            userData.pwd,
            userData.age,
            userData.gender,
            userData.address,
            userData.phone,
            userData.imgUrl
        );
        return userId;
    } catch (err) {
        console.error("Error creating user:", err);
        throw err;
    }
};

// 更新用户
exports.updateUser = async (userData) => {
    try {
        await User.updateUser(
            userData.id,
            userData.name,
            userData.pwd,
            userData.age,
            userData.gender,
            userData.address,
            userData.phone,
            userData.imgUrl
        );
    } catch (err) {
        console.error(`Error updating user with ID ${userData.id}:`, err);
        throw err;
    }
};

// 修改用户密码
exports.changePassword = async (userId, newPwd) => {
    try {
        await User.changePassword(userId, newPwd);
    } catch (err) {
        console.error(`Error changing password for user with ID ${userId}:`, err);
        throw err;
    }
};

// 删除用户
exports.deleteUser = async (userId) => {
    try {
        await User.deleteUser(userId);
    } catch (err) {
        console.error(`Error deleting user with ID ${userId}:`, err);
        throw err;
    }
};

