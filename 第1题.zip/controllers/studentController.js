const userService = require("../services/userService")

//登录
exports.login = async (req, res, next) => {
    try {
        //如果加了的字段也算作登录功能里头，在此添加
        const { name, pwd, phone } = req.body;
        const user = await userService.getUserByName(name);
        if (!user) {
            return res.send({
                code: 1001,
                success: false,
                message: "账号不存在",
            });
        }
        if (user.pwd !== pwd) {
            return res.send({
                code: 1002,
                success: false,
                message: "密码错误",
            });
        }
        if (user.phone !== phone) {
            return res.send({
                code: 1002,
                success: false,
                message: "手机号错误",
            });
        }
        req.session.loginUser = user.name;
        console.log(req.session);

        req.session.save(() => {
            //判断是普通用户还是管理员
            if (user.name === "20222830") {
                res.redirect("/stus/students");
            } else {
                res.redirect(`/stus/students/${user.id}`);
            }
        });
    } catch (err) {
        next(err);
    }
};

//返回用户信息，渲染管理员登陆的页面
exports.getStudents = async (req, res, next) => {
    try {
        const users = await userService.getUsers();

        // 渲染模板，获取并清空错误信息
        const errorMessage = req.session.errorMessage || null;
        req.session.errorMessage = null; // 清空错误信息

        res.render("students", {
            stus: users,
            loginUserName: req.session.loginUser,
            errorMessage: errorMessage, // 传递错误信息到前端
        });
    } catch (err) {
        next(err);
    }
};

//普通用户登录的效果
exports.getUserById = async (req, res, next) => {
    try {

        const user = await userService.getUserById(req.params.id);
        if (!user) {
            return null;
        } else {
            //管理员修改和普通用户登录都渲染这个
            res.render("student", { student: user });
        }
    } catch (err) {
        next(err);
    }
};

//登出功能
exports.logout = async (req, res, next) => {
    res.redirect("/");

};

// 创建新用户
exports.createUser = async (req, res, next) => {
    try {
        const newUser = req.body;

        // 检查是否有重名用户
        const existingUser = await userService.getUserByName(newUser.name);

        if (existingUser) {
            // 如果用户名已存在，设置错误信息到 session 中
            req.session.errorMessage = "用户名已存在，请选择其他用户名！";
            return res.redirect("/stus/students"); // 重定向到列表页
        } else {
            // 如果用户名不存在，继续创建新用户
            newUser.age = +newUser.age;
            newUser.imgUrl = "http://localhost:8000/images/peoples/员工.png";
            await userService.createUser(newUser);

            // 创建成功后重定向
            res.redirect("/stus/students");
        }
    } catch (err) {
        next(err);
    }
};



//删除用户
exports.deleteUser = async (req, res, next) => {
    try {
        const userId = req.params.id;
        await userService.deleteUser(userId);
        res.redirect("/stus/students");
    } catch (err) {
        next(err);
    }
};

//更新用户
exports.updateUser = async (req, res, next) => {
    try {
        const updatedUser = req.body;
        const updateUserResult = await userService.getUserById(updatedUser.id);
        updatedUser.imgUrl = updateUserResult.imgUrl;
        await userService.updateUser(updatedUser);
        res.redirect("/stus/students");
    } catch (err) {
        next(err);
    }
};

//注册用户
exports.regist = async (req, res, next) => {
    try {
        const newuser = req.body
        const user = await userService.getUserByName(newuser.name)
        if (user) {
            res.redirect("/userRegister.html")
            // 如果用户已存在，重定向到注册页面并附带错误参数
            //res.redirect("/userRegister.html?error=1");
        } else {
            newuser.imgUrl = "http://localhost:8000/images/peoples/员工.png";
            await userService.createUser(newuser)
            res.redirect("/usersCenter.html")
        }
    } catch (err) {
        next(err)
    }
}


// 渲染修改密码的页面
exports.renderChangePasswordPage = async (req, res, next) => {
    try {
        const userId = req.params.id; // 从请求参数中获取用户 ID
        const user = await userService.getUserById(userId); // 从数据库中获取用户信息
        if (!user) {
            return res.send({
                code: 1001,
                success: false,
                message: "用户不存在",
            });
        }
        // 渲染页面时传递旧密码
        res.render("changePwd", {
            userId,
            oldPwd: user.pwd,
        });
    } catch (err) {
        next(err);
    }
};

// 处理修改密码的请求
exports.changePassword = async (req, res, next) => {
    try {
        const { userId, newPwd, oldPwd, confirmNewPwd } = req.body;
        const user = await userService.getUserById(userId);
        // 检查用户ID和密码是否存在
        if (!userId || !newPwd) {
            return res.send({
                code: 1002,
                success: false,
                message: "缺少参数：用户ID 或 新密码",
            });
        }
        if (oldPwd !== user.pwd) {
            return res.send({
                code: 1002,
                success: false,
                message: "新密码和旧密码不一致",
            });
        }
        // 检查新密码和确认密码是否一致
        if (newPwd !== confirmNewPwd) {
            return res.send({
                code: 1002,
                success: false,
                message: "新密码和确认密码不一致",
            });
        }

        // 调用服务层逻辑修改密码
        await userService.changePassword(userId, newPwd);

        res.redirect("/stus/students")
    } catch (err) {
        console.error("Error changing password:", err);
        next(err);
    }
};

// 增加年龄
exports.increaseAge = async (req, res, next) => {
    try {
        const userId = req.params.id;
        const user = await userService.getUserById(userId);
        if (!user) {
            return res.send({
                code: 1001,
                success: false,
                message: "用户未找到"
            });
        }

        user.age += 1;  // 增加年龄
        await userService.updateUser(user);

        res.redirect("/stus/students");  // 跳转回学生列表页面
    } catch (err) {
        next(err);
    }
};

// 减少年龄
exports.decreaseAge = async (req, res, next) => {
    try {
        const userId = req.params.id;
        const user = await userService.getUserById(userId);
        if (!user) {
            return res.status(404).send({
                code: 1001,
                success: false,
                message: "用户未找到"
            });
        }

        if (user.age > 0) {  // 防止年龄为负
            user.age -= 1;  // 减少年龄
        }

        await userService.updateUser(user);

        res.redirect("/stus/students");  // 跳转回学生列表页面
    } catch (err) {
        next(err);
    }
};

// 增加电话号码
exports.increasePhone = async (req, res, next) => {
    try {
        const userId = req.params.id;
        const user = await userService.getUserById(userId);
        if (!user) {
            return res.send({
                code: 1001,
                success: false,
                message: "用户未找到"
            });
        }

        const phone = parseInt(user.phone, 10);
        if (isNaN(phone)) {
            return res.send({
                code: 400,
                message: '电话号码格式错误'
            });
        }
        user.phone = (phone + 1).toString();
        await userService.updateUser(user);

        res.redirect("/stus/students");  // 跳转回学生列表页面
    } catch (err) {
        next(err);
    }
};

// 减少电话号码
exports.decreasePhone = async (req, res) => {
    try {
        const userId = req.params.id;
        const user = await userService.getUserById(userId);
        if (!user) {
            return res.send({
                code: 1001,
                success: false,
                message: "用户未找到"
            });
        }

        const phone = parseInt(user.phone, 10);
        if (isNaN(phone)) {
            return res.send({
                code: 400,
                message: '电话号码格式错误'
            });
        }
        if (phone <= 0) {
            return res.send({
                code: 400,
                message: '电话号码不能小于0'
            });
        }
        user.phone = (phone - 1).toString();
        //student.phone = student.phone.slice(0, -1); // 示例：移除手机号最后一个字符
        //student.phone += '1'; // 示例：在手机号末尾添加“1”
        await userService.updateUser(user);

        res.redirect("/stus/students");  // 跳转回学生列表页面
    } catch (err) {
        next(err);
    }
};
