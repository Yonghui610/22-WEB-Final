const movieService = require("../services/movieService");
const userService = require("../services/userService");

//电影管理登录
exports.login = async (req, res, next) => {
    try {
        const { name, pwd, phone } = req.body;
        const user = await userService.getUserByName(name);
        if (!user) {
            return res.send({
                code: 1001,
                success: false,
                message: "账号不存在",
            });
        }
        if (user.pwd !== pwd) {
            return res.send({
                code: 1002,
                success: false,
                message: "密码错误",
            });
        }

        if (user.phone !== phone) {
            return res.send({
                code: 1002,
                success: false,
                message: "手机号错误",
            });
        }
        req.session.loginUser = user.name;
        console.log(req.session);
        req.session.save(() => {
            //判断是普通用户还是管理员（学号）
            if (user.name === "20222830") {
                res.redirect("/movs/movies");
            } else {
                res.redirect(`/moviesCenter.html`);
            }
        });
    } catch (err) {
        next(err);
    }
};

//获取全部电影（管理员登陆后的界面）
exports.getMovies = async (req, res, next) => {
    try {
        const movies = await movieService.getMovies();
        res.render("movies", { movs: movies, loginUserName: req.session.loginUser });
    } catch (err) {
        next(err);
    }
};

//展示全部电影（修改后的界面）
exports.getAllMovie = async (req, res, next) => {
    try {
        const movies = await movieService.getMovies();
        res.render("Allmovie", { movs: movies });

    } catch (err) {
        next(err);
    }
};

//根据id获取电影
exports.getMovieById = async (req, res, next) => {
    try {
        const movie = await movieService.getMovieById(req.params.id);
        if (!movie) {
            return null;
        } else {
            res.render("movieModify", { movie: movie });
        }
    } catch (err) {
        next(err);
    }
};

//登出
exports.logout = async (req, res, next) => {
    res.redirect("/");
};

//创建新电影
exports.createMovie = async (req, res, next) => {
    try {
        const newMovie = req.body;
        console.log(newMovie);
        const createMovieResult = await movieService.getMovieByName(newMovie.name);
        if (createMovieResult) {
            res.redirect("/movs/movies");
        } else {
            newMovie.posterUrl = "http://localhost:8000/images/movies/通用图片.jpeg";
            await movieService.createMovie(newMovie);

            res.redirect("/movs/movies/all");
        }
    } catch (err) {
        next(err);
    }
};

//根据id删除电影
exports.deleteMovie = async (req, res, next) => {
    try {
        const movieId = req.params.id;
        await movieService.deleteMovie(movieId);
        res.redirect("/movs/movies/all");
    } catch (err) {
        next(err);
    }
};

//修改电影内容
exports.updateMovie = async (req, res, next) => {
    try {
        const updatedMovie = req.body;
        const updateMovieResult = await movieService.getMovieById(updatedMovie.filmId);
        updatedMovie.posterUrl = updateMovieResult.posterUrl;
        await movieService.updateMovie(updatedMovie);

        res.redirect("/movs/movies/all");
    } catch (err) {
        next(err);
    }
};


exports.getMovieList = async (req, res, next) => {
    try {
        const movies = await movieService.getMovies(); // 从数据库获取电影数据
        res.json({
            code: 200,
            success: true,
            movies // 返回电影列表
        });
    } catch (err) {
        next(err);
    }
};

//电影细节（和首页电影有关）
exports.movieDetail = async (req, res, next) => {
    try {
        const filmId = req.params.id; // 从路径参数获取 filmId
        const movie = await movieService.getMovieById(filmId); // 基于 filmId 查询

        if (!movie) {
            return res.json({ success: false, message: "电影未找到" });
        } else {
            res.json({
                code: 200,
                success: true,
                data: { film: movie } // 返回前端预期的数据结构
            });
        }
    } catch (err) {
        console.error("Error fetching movie details:", err);
        next(err);
    }
};


// 修改电影人气值
exports.updatePopularity = async (req, res, next) => {
    try {
        const { filmId, change } = req.body; // 确保使用req.body获取参数

        if (!filmId || isNaN(change)) {
            return res.json({
                code: 400,
                success: false,
                message: "无效的参数"
            });
        }

        const updatedPopularity = await movieService.updatePopularity(filmId, parseInt(change));

        res.json({
            code: 200,
            success: true,
            updatedPopularity
        });
    } catch (err) {
        console.error("更新电影人气值失败:", err);
        next(err);
    }
};

//修改flimId
exports.updateFilmId = async (req, res, next) => {
    try {
        const { filmId, change } = req.body;

        if (!filmId || isNaN(change)) {
            return res.json({
                code: 400,
                success: false,
                message: "无效的参数"
            });
        }

        const newFilmId = await movieService.updateFilmId(filmId, parseInt(change));
        res.json({
            code: 200,
            success: true,
            newFilmId
        });
    } catch (err) {
        console.error("Error in updateFilmId:", err.message);
        // 返回更详细的错误信息给前端
        res.json({
            code: 500,
            success: false,
            message: err.message || "未知错误"
        });
    }
};
