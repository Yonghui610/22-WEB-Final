const express = require("express");
const router = express.Router();
const movieController = require("../controllers/movieController");

// 登录    
router.post("/movies/login", movieController.login);

//登出
router.get("/movies/logout", movieController.logout);

// 获取所有电影（管理员登陆版本）
router.get("/movies", movieController.getMovies);
// 获取所有电影（修改完毕版本）
router.get("/movies/all", movieController.getAllMovie);

//首页电影展示
router.get("/movies/show", movieController.getMovieList);

//点击海报跳转
router.get("/moviedetail/:id", movieController.movieDetail);

// 添加新电影
router.post("/movies", movieController.createMovie);

// 根据 ID 获取单个用户
router.get("/movies/:id", movieController.getMovieById);

// 删除用户
router.delete("/movies/:id", movieController.deleteMovie);

// 用get方法模拟delete
router.get("/movies/delete/:id", movieController.deleteMovie);


// router.put("/movies", movieController.updateMovie);

// 修改电影内容
router.post("/movies/update", movieController.updateMovie);
//修改flimId
router.post("/movies/updateFilmId", movieController.updateFilmId);
//修改评分
router.post("/movies/updatePopularity", movieController.updatePopularity);

module.exports = router;

