const express = require("express");
const router = express.Router();
const studentController = require("../controllers/studentController");

// 登录    
router.post("/students/login", studentController.login);

// 登出
router.get("/students/logout", studentController.logout);

// 注册普通新用户
router.post("/studentRegister", studentController.regist);

// 获取所有用户
router.get("/students", studentController.getStudents);

// 添加新用户
router.post("/students", studentController.createUser);

// 根据 ID 获取单个用户
router.get("/students/:id", studentController.getUserById);

// 删除用户
router.get("/students/delete/:id", studentController.deleteUser);

// 更新用户
router.post("/students/update", studentController.updateUser);

//改密码
router.get("/students/mofpwd/:id", studentController.renderChangePasswordPage);
router.post("/students/changePassword", studentController.changePassword)

// 增加年龄
router.get("/students/age/increase/:id", studentController.increaseAge);
// 减少年龄
router.get("/students/age/decrease/:id", studentController.decreaseAge);
// 增加电话号码
router.get('/students/phone/increase/:id', studentController.increasePhone);
//减少电话号码
router.get('/students/phone/decrease/:id', studentController.decreasePhone);


module.exports = router;

