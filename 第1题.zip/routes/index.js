const express = require("express");
const router = express.Router();
router.use("/movs", require("./movies"));
router.use("/stus", require("./students"));
module.exports = router;