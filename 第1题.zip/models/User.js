const { createPool } = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");
const pool = createPool(dbConfig);

class User {
    constructor(id, name, pwd, age, gender, address, phone, imgUrl) {
        this.id = id;
        this.name = name;
        this.pwd = pwd;
        this.age = age;
        this.gender = gender;
        this.address = address;
        this.phone = phone;
        this.imgUrl = imgUrl;
    }

    // 获取所有用户
    static async getUsers() {
        try {
            const [rows] = await pool.query("SELECT * FROM wyhtable1");
            return rows.map(
                (row) =>
                    new User(
                        row.id,
                        row.name,
                        row.pwd,
                        row.age,
                        row.gender,
                        row.address,
                        row.phone,
                        row.imgUrl
                    )
            );
        } catch (err) {
            console.error("Error fetching users:", err);
            throw err;
        }
    }

    //根据姓名获取用户
    static async getUserByName(name) {
        try {
            const [rows] = await pool.query("select * from wyhtable1 where name = ?", [
                name,
            ]);
            if (rows.length === 0) {
                return null;
            }
            //返回用户
            return new User(
                rows[0].id,
                rows[0].name,
                rows[0].pwd,
                rows[0].age,
                rows[0].gender,
                rows[0].address,
                rows[0].phone,
                rows[0].imgUrl
            );
        } catch (err) {
            console.error(`Error fetching user with Name ${name}:`, err);
            throw err;
        }
    }

    //根据id获取用户
    static async getUserById(id) {
        try {
            const [rows] = await pool.query("SELECT * FROM wyhtable1 WHERE id = ?", [id]);
            if (rows.length === 0) {
                return null;
            }
            //有返回值
            return new User(
                rows[0].id,
                rows[0].name,
                rows[0].pwd,
                rows[0].age,
                rows[0].gender,
                rows[0].address,
                rows[0].phone,
                rows[0].imgUrl
            );
        } catch (err) {
            console.error(`Error fetching user with ID ${id}:`, err);
            throw err;
        }
    }

    //创建新用户
    static async createUser(name, pwd, age, gender, address, phone, imgUrl) {
        try {
            const [result] = await pool.query(
                "INSERT INTO wyhtable1 (name, pwd, age, gender, address,phone,imgUrl) VALUES (?, ?, ?, ?, ?, ?,?)",
                [name, pwd, age, gender, address, phone, imgUrl]
            );
            // 返回新插入记录的 ID
            return result.insertId;
        } catch (err) {
            console.error("Error creating user:", err);
            throw err;
        }
    }

    //更新用户信息
    static async updateUser(id, name, pwd, age, gender, address, phone, imgUrl) {
        try {
            await pool.query(
                "UPDATE wyhtable1 SET name = ?, pwd = ?, age = ? , gender = ? , address = ?, phone=?,imgUrl = ? WHERE id = ?",
                [name, pwd, age, gender, address, phone, imgUrl, id]
            );
            // 木有返回值
        } catch (err) {
            console.error(`Error updating user with ID ${id}:`, err);
            throw err;
        }
    }

    static async deleteUser(id) {
        try {
            await pool.query("DELETE FROM wyhtable1 WHERE id = ?", [id]);
            // 木有返回值
        } catch (err) {
            console.error(`Error deleting user with ID ${id}:`, err);
            throw err;
        }
    }

    // 增加修改密码的功能
    static async changePassword(id, newPwd) {
        try {
            await pool.query(
                "UPDATE wyhtable1 SET pwd = ? WHERE id = ?",
                [newPwd, id]
            );
        } catch (err) {
            console.error(`Error changing password for user with ID ${id}:`, err);
            throw err;
        }
    }

}

module.exports = User;
