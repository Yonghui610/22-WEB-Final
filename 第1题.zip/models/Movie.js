const { createPool } = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");
const pool = createPool(dbConfig);

class Movie {
    constructor(id, filmId, name, description, posterUrl, popularity) {
        this.id = id;
        this.filmId = filmId
        this.name = name;
        this.description = description;
        this.posterUrl = posterUrl;
        this.popularity = popularity;
    }
    //获取所有电影
    static async getMovies() {
        try {
            const [rows] = await pool.query("SELECT * FROM wyhtable2");
            return rows.map(
                (row) =>
                    new Movie(
                        row.id,
                        row.filmId,
                        row.name,
                        row.description,
                        row.posterUrl,
                        row.popularity
                    )
            );
        } catch (err) {
            console.error("Error fetching movies:", err);
            throw err;
        }
    }

    //通过名称获取电影
    static async getMovieByName(name) {
        try {
            const [rows] = await pool.query("select * from wyhtable2 where name = ?", [
                name,
            ]);
            if (rows.length === 0) {
                return null;
            }
            return new Movie(
                rows[0].id,
                rows[0].filmId,
                rows[0].name,
                rows[0].description,
                rows[0].posterUrl,
                rows[0].popularity
            );
        } catch (err) {
            console.error(`Error fetching movie with Name ${name}:`, err);
            throw err;
        }
    }

    //通过电影ID获取电影
    static async getMovieById(filmId) {
        try {
            const [rows] = await pool.query("SELECT * FROM wyhtable2 WHERE filmId = ?", [filmId]);
            if (rows.length === 0) {
                return null;
            }
            return new Movie(
                rows[0].id,
                rows[0].filmId,
                rows[0].name,
                rows[0].description,
                rows[0].posterUrl,
                rows[0].popularity
            );
        } catch (err) {
            console.error(`Error fetching movie with filmId ${filmId}:`, err);
            throw err;
        }
    }

    //创建一个新电影
    static async createMovie(filmId, name, description, posterUrl, popularity) {
        try {
            const [result] = await pool.query(
                "INSERT INTO wyhtable2 (filmId, name, description, posterUrl, popularity) VALUES (?, ?, ?, ?, ?)",
                [filmId, name, description, posterUrl, popularity]
            );
            return result.insertId;
        } catch (err) {
            console.error("Error creating movie:", err);
            throw err;
        }
    }

    //修改电影
    static async updateMovie(id, filmId, name, description, posterUrl, popularity) {
        try {
            await pool.query(
                "UPDATE wyhtable2 SET filmId = ?,  name = ?, description = ?, posterUrl = ? , popularity = ? WHERE id = ?",
                [filmId, name, description, posterUrl, popularity, id]
            );
        } catch (err) {
            console.error(`Error updating movie with ID ${id}:`, err);
            throw err;
        }
    }

    //删除电影
    static async deleteMovie(id) {
        try {
            await pool.query("DELETE FROM wyhtable2 WHERE id = ?", [id]);
        } catch (err) {
            console.error(`Error deleting movie with ID ${id}:`, err);
            throw err;
        }
    }

    //修改人气值
    static async updatePopularity(filmId, change) {
        try {
            // 使用 SQL 的 UPDATE 和 SET 语句更新人气值
            const [result] = await pool.query(
                "UPDATE wyhtable2 SET popularity = popularity + ? WHERE filmId = ?",
                [change, filmId]
            );

            // 判断更新结果
            if (result.affectedRows === 0) {
                throw new Error("电影未找到或更新失败");
            }

            // 返回更新后的人气值
            const [rows] = await pool.query("SELECT popularity FROM wyhtable2 WHERE filmId = ?", [filmId]);
            return rows[0].popularity;
        } catch (err) {
            console.error(`Error updating popularity for movie with filmId ${filmId}:`, err);
            throw err;
        }
    }

    //修改电影ID
    static async updateFilmId(filmId, change) {
        try {
            // 确保 filmId 是字符串
            const currentFilmId = String(filmId);
            const newFilmId = String(parseInt(currentFilmId) + change);

            // 检查新的 filmId 是否已存在，避免冲突
            const [existingRows] = await pool.query("SELECT * FROM wyhtable2 WHERE filmId = ?", [newFilmId]);
            if (existingRows.length > 0) {
                throw new Error(`电影ID ${newFilmId} 已存在，无法更新。`);
            }

            // 更新 filmId
            const [result] = await pool.query(
                "UPDATE wyhtable2 SET filmId = ? WHERE filmId = ?",
                [newFilmId, currentFilmId]
            );

            if (result.affectedRows === 0) {
                throw new Error(`电影ID ${currentFilmId} 未找到或更新失败`);
            }

            return newFilmId;
        } catch (err) {
            console.error(`Error in updateFilmId: ${err.message}`);
            throw err;
        }
    }

}

module.exports = Movie;
