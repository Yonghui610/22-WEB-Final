const btn = document.getElementById("wyh4")
const box1 = document.getElementById("wyh2")
const box3 = document.getElementById("wyh3")
btn.addEventListener("click", function () {
    box1.style.height = 830 + "px";
    box3.style.height = 830 + "px";
})