const height = 111;
const big = document.getElementById("wyh");
const house = document.getElementById("wyh1");
window.addEventListener("scroll", function () {
    const scrolltop = this.document.documentElement.scrollTop;
    if (scrolltop >= height) {
        big.style.visibility = "hidden";
        house.style.visibility = " visible";
    } else {
        big.style.visibility = " visible";
        house.style.visibility = " hidden";
    }
})