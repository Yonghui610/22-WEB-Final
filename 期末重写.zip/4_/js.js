const gameList = document.getElementById("gameList");

const gameStates = ["新服刚开一秒", "新服刚开", "长久耐玩"];
const gameStateColors = ["red", "green", "blue"];

function createGameListItem(index) {
    const li = document.createElement("li");
    li.className = "list-item";
    li.innerHTML = `
        <div class="game-rank-header">
            <span class="rank-number">${index + 1}</span>: 热门游戏吴咏慧<span class="rank-extra">${index + 1}</span>
        </div>
        <div class="game-details">
            <div class="game-image">热门游戏吴咏慧<span class="image-number">${index + 1}</span>图片</div>
            <div class="game-info">
                <h4>官方推荐</h4>
                <p class="game-state">${gameStates[0]}</p>
                <button class="game-start">点击登陆热门游戏吴咏慧<span class="button-number">${index + 1}</span></button>
            </div>
        </div>`;

    // 动态获取当前游戏编号
    li.querySelector(".game-start").addEventListener("click", function () {
        const currentRank = li.querySelector(".rank-number").textContent;
        alert(`热门游戏吴咏慧${currentRank}`);
    });

    return li;
}
function updateGameListItems() {
    const items = gameList.children;

    for (let i = 0; i < items.length; i++) {
        const rankNumber = items[i].querySelector(".rank-number");
        const rankExtra = items[i].querySelector(".rank-extra");
        const buttonNumber = items[i].querySelector(".button-number");
        const imageNumber = items[i].querySelector(".image-number");
        const stateText = items[i].querySelector(".game-state");

        rankNumber.textContent = i + 1;
        rankExtra.textContent = i + 1;
        buttonNumber.textContent = i + 1;
        imageNumber.textContent = i + 1;

        if (i === 0) {
            stateText.textContent = gameStates[0];
            stateText.style.color = gameStateColors[0];
        } else if (i === 1 || i === 2) {
            stateText.textContent = gameStates[1];
            stateText.style.color = gameStateColors[1];
        } else {
            stateText.textContent = gameStates[2];
            stateText.style.color = gameStateColors[2];
        }
    }
}


document.getElementById("prepend").addEventListener("click", () => {
    const newItem = createGameListItem(gameList.children.length);
    gameList.insertBefore(newItem, gameList.firstChild);
    updateGameListItems();
});

document.getElementById("removeLast").addEventListener("click", () => {
    if (gameList.children.length > 6) {
        gameList.removeChild(gameList.lastChild);
        updateGameListItems();
    } else {
        alert("游戏列表中至少保留6个游戏！");
    }
});

gameList.addEventListener("mouseover", (event) => {
    const targetItem = event.target.closest("li");
    if (targetItem) {
        // 使用 for 循环遍历 gameList.children
        for (let i = 0; i < gameList.children.length; i++) {
            let item = gameList.children[i];
            item.querySelector(".game-details").style.height = "0";
        }
        // 展开当前悬停的项的详情
        targetItem.querySelector(".game-details").style.height = 103 + "px";
    }
});

