const height = 202;
const login = document.getElementById("wyh4");
const register = document.getElementById("wyh1");
const btn = document.getElementById("wyh2");
window.addEventListener("scroll", function () {
    const scrollheight = document.documentElement.scrollTop;
    if (scrollheight > height) {
        login.style.visibility = "visible";
    } else {
        login.style.visibility = "hidden";
    }
})

login.addEventListener("click", function () {
    register.style.visibility = "visible";
})

btn.addEventListener("click", function () {
    register.style.visibility = "hidden";
})
